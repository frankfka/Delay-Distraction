# Delay Distraction
A Firefox extension to inject latency into page loads.
